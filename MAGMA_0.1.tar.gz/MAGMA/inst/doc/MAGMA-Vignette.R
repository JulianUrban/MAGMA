## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>")

## ----setup, include = FALSE---------------------------------------------------
library(MAGMA)

## ----data_introduction--------------------------------------------------------
str(MAGMA_sim_data)

head(MAGMA_sim_data)

## ----data_descriptives--------------------------------------------------------
MAGMA_sim_data %>%
  select(sex, gifted_support, teacher_ability_rating, enrichment,
         parents_academic, GPA_school, IQ_score, Motivation, college_GPA) %>%
  psych::describe()

MAGMA_sim_data %>%
  select(sex, gifted_support, teacher_ability_rating, enrichment,
         parents_academic, GPA_school, IQ_score, Motivation, college_GPA) %>%
  cor()

## ----covariates_gifted--------------------------------------------------------
covariates_gifted <- c("GPA_school", "IQ_score", "Motivation", "parents_academic", "sex")

## ----unbalance_gifted---------------------------------------------------------
unbalance_gifted <- initial_unbalance(data = MAGMA_sim_data,
                                      group = "gifted_support",
                                      covariates = covariates_gifted)
unbalance_gifted

## ----standard_2_group_matching------------------------------------------------
MAGMA_sim_data_gifted <- MAGMA(Data = MAGMA_sim_data,
                                group = "gifted_support",
                                dist = "ps_gifted",
                                cores = 2)
str(MAGMA_sim_data_gifted)

## ----Balance_standard_2_group_matching----------------------------------------
Balance_gifted <- Balance_MAGMA(data = MAGMA_sim_data_gifted,
                                group = "gifted_support",
                                covariates = covariates_gifted,
                                step = "step") #Not necessary to define here

str(Balance_gifted) #NA's result of minimum required sample size

#Balance criteria for a 100 cases per group
Balance_100_gifted <- c(Balance_gifted$Pillai[100],
                        Balance_gifted$d_ratio$d_rate[100],
                        Balance_gifted$mean_effect[100],
                        Balance_gifted$adjusted_d_ratio[100])
Balance_100_gifted

Balance_gifted$d_ratio$effects[, 100]

## ----Plots_standard_2_group_matching, fig.height = 5, fig.width = 7.5---------
Plot_MAGMA(Balance = Balance_gifted,
           criterion = c("Pillai", "d_ratio", "mean_g", "Adj_d_ratio")) #Could be omitted

## ----Table_standard_2_group_matching------------------------------------------
Table_MAGMA(Balance = Balance_gifted,
            filename = "Balance_gifted.docx")

## ----exact_2_group_matching---------------------------------------------------
MAGMA_sim_data_gifted_exact <- MAGMA_exact(Data = MAGMA_sim_data,
                                           group = "gifted_support",
                                           dist = "ps_gifted",
                                           exact = "enrichment",
                                           cores = 2)
str(MAGMA_sim_data_gifted_exact)

## ----Balance_exact_2_group_matching, fig.height = 5, fig.width = 7.5----------
Balance_gifted_exact <- Balance_MAGMA(data = MAGMA_sim_data_gifted_exact,
                                      group = "gifted_support",
                                      covariates = covariates_gifted,
                                      step = "step") #Not necessary to define here

str(Balance_gifted_exact)

#Balance criteria for a 100 cases per group
Balance_100_gifted_exact <- c(Balance_gifted_exact$Pillai[100],
                              Balance_gifted_exact$d_ratio$d_rate[100],
                              Balance_gifted_exact$mean_effect[100],
                              Balance_gifted_exact$adjusted_d_ratio[100])
Balance_100_gifted_exact

Balance_gifted_exact$d_ratio$effects[, 100]

#Ploting trend over increasing samle size
Plot_MAGMA(Balance = Balance_gifted_exact,
           criterion = c("Pillai", "d_ratio", "mean_g", "Adj_d_ratio")) #Could be omitted

#Creating APA table
Table_MAGMA(Balance = Balance_gifted_exact,
            filename = "Balance_gifted_exact.docx")


## ----covariates_tar-----------------------------------------------------------
covariates_tar <- c("GPA_school", "IQ_score", "Motivation", "parents_academic", "gifted_support")

## ----unbalance_tar------------------------------------------------------------
unbalance_tar <- initial_unbalance(data = MAGMA_sim_data,
                                   group = "teacher_ability_rating",
                                   covariates = covariates_tar)
unbalance_tar

## ----standard_3_group_matching------------------------------------------------
MAGMA_sim_data_tar <- MAGMA(Data = MAGMA_sim_data,
                            group = "teacher_ability_rating",
                            dist = "ps_tar",
                            cores = 2)
str(MAGMA_sim_data_tar)

## ----Balance_3_group_matching, fig.height = 5, fig.width = 7.5----------------
Balance_tar <- Balance_MAGMA(data = MAGMA_sim_data_tar,
                                      group = "teacher_ability_rating",
                                      covariates = covariates_tar,
                                      step = "step") #Not necessary to define here

str(Balance_tar)

#Balance criteria for a 100 cases per group
Balance_100_tar <- c(Balance_tar$Pillai[100],
                     Balance_tar$d_ratio$d_rate[100],
                     Balance_tar$mean_effect[100],
                     Balance_tar$adjusted_d_ratio[100])
Balance_100_tar

Balance_tar$d_ratio$effects[, 100]

#Ploting trend over increasing samle size
Plot_MAGMA(Balance = Balance_tar,
           criterion = c("Pillai", "d_ratio", "mean_g", "Adj_d_ratio")) #Could be omitted

#Creating APA table
Table_MAGMA(Balance = Balance_tar,
            filename = "Balance_tar.docx")


## ----exact_3_group_matching, fig.height = 5, fig.width = 7.5------------------
MAGMA_sim_data_tar_exact <- MAGMA_exact(Data = MAGMA_sim_data,
                                        group = "teacher_ability_rating",
                                        dist = "ps_tar",
                                        exact = "sex",
                                        cores = 2)
str(MAGMA_sim_data_tar_exact)

Balance_tar_exact <- Balance_MAGMA(data = MAGMA_sim_data_tar_exact,
                                   group = "teacher_ability_rating",
                                   covariates = covariates_tar,
                                   step = "step") #Not necessary to define here

str(Balance_tar_exact)

#Balance criteria for a 100 cases per group
Balance_100_tar_exact <- c(Balance_tar_exact$Pillai[100],
                           Balance_tar_exact$d_ratio$d_rate[100],
                           Balance_tar_exact$mean_effect[100],
                           Balance_tar_exact$adjusted_d_ratio[100])
Balance_100_tar_exact

Balance_tar_exact$d_ratio$effects[, 100]

#Ploting trend over increasing samle size
Plot_MAGMA(Balance = Balance_tar_exact,
           criterion = c("Pillai", "d_ratio", "mean_g", "Adj_d_ratio")) #Could be omitted

#Creating APA table
Table_MAGMA(Balance = Balance_tar_exact,
            filename = "Balance_tar_exact.docx")

## ----covariates_2x2-----------------------------------------------------------
covariates_2x2 <- c("GPA_school", "IQ_score", "Motivation", "parents_academic", "sex")

## ----unbalance_2x2------------------------------------------------------------
unbalance_2x2 <- initial_unbalance(data = MAGMA_sim_data,
                                   group = c("gifted_support", "enrichment"),
                                   covariates = covariates_2x2)
unbalance_2x2

unbalance_4_group <- initial_unbalance(data = MAGMA_sim_data,
                                   group = "support_enrichment",
                                   covariates = covariates_2x2)
unbalance_4_group

## ----standard_2x2_group_matching----------------------------------------------
MAGMA_sim_data_2x2 <- MAGMA(Data = MAGMA_sim_data,
                            group = c("gifted_support", "enrichment"),
                            dist = "ps_2x2",
                            cores = 2)
str(MAGMA_sim_data_2x2)

MAGMA_sim_data_four_group <- MAGMA(Data = MAGMA_sim_data,
                            group = "support_enrichment",
                            dist = "ps_2x2",
                            cores = 2)
str(MAGMA_sim_data_four_group)

#Making data frames comparable
MAGMA_sim_data_2x2_comp <- MAGMA_sim_data_2x2 %>%
  select(step, weight, distance)

MAGMA_sim_data_four_group_comp <- MAGMA_sim_data_four_group %>%
  select(step, weight, distance)

#ColSums equal the number of cases
identical(MAGMA_sim_data_2x2_comp, MAGMA_sim_data_four_group_comp)

## ----Balance_2x2_group_matching, fig.height = 5, fig.width = 7.5--------------
Balance_2x2 <- Balance_MAGMA(data = MAGMA_sim_data_2x2,
                             group = c("gifted_support", "enrichment"),
                             covariates = covariates_2x2,
                             step = "step") #Not necessary to define here

str(Balance_2x2)

#Balance criteria for a 100 cases per group
Balance_100_2x2 <- c(Balance_2x2$Pillai[1, 100],
                     Balance_2x2$Pillai[2, 100],
                     Balance_2x2$Pillai[3, 100],
                     Balance_2x2$d_ratio$d_rate[100],
                     Balance_2x2$mean_effect[100],
                     Balance_2x2$adjusted_d_ratio[100])
Balance_100_2x2

Balance_2x2$d_ratio$effects[, 100]

#Ploting trend over increasing samle size
Plot_MAGMA(Balance = Balance_2x2,
           criterion = c("Pillai", "d_ratio", "mean_g", "Adj_d_ratio")) #Could be omitted

#Creating APA table
Table_MAGMA(Balance = Balance_2x2,
            filename = "Balance_2x2.docx")


## ----exact_2x2_group_matching, fig.height = 5, fig.width = 7.5----------------
MAGMA_sim_data_2x2_exact <- MAGMA_exact(Data = MAGMA_sim_data,
                                        group = c("gifted_support", "enrichment"),
                                        dist = "ps_2x2",
                                        exact = "teacher_ability_rating",
                                        cores = 2)
str(MAGMA_sim_data_2x2_exact)

Balance_2x2_exact <- Balance_MAGMA(data = MAGMA_sim_data_2x2_exact,
                                   group = c("gifted_support", "enrichment"),
                                   covariates = covariates_2x2,
                                   step = "step") #Not necessary to define here

str(Balance_2x2_exact)

#Balance criteria for a 100 cases per group
Balance_100_2x2_exact <- c(Balance_2x2_exact$Pillai[1, 100],
                           Balance_2x2_exact$Pillai[2, 100],
                           Balance_2x2_exact$Pillai[3, 100],
                           Balance_2x2_exact$d_ratio$d_rate[100],
                           Balance_2x2_exact$mean_effect[100],
                           Balance_2x2_exact$adjusted_d_ratio[100])
Balance_100_2x2_exact

Balance_2x2_exact$d_ratio$effects[, 100]

#Ploting trend over increasing sample size
Plot_MAGMA(Balance = Balance_2x2_exact,
           criterion = c("Pillai", "d_ratio", "mean_g", "Adj_d_ratio")) #Could be omitted

#Creating APA table
Table_MAGMA(Balance = Balance_2x2_exact,
            filename = "Balance_2x2_exact.docx")

